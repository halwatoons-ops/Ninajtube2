import discord
from discord.ext import commands
import os

TOKEN = os.getenv("TOKEN")
SCREENSHOT_CHANNEL_ID = int(os.getenv("SCREENSHOT_CHANNEL_ID", 0))
ROLE_ID = int(os.getenv("ROLE_ID", 0))
GUILD_ID = int(os.getenv("GUILD_ID", 0))

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="/", intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.command()
async def verify(ctx):
    await ctx.send("Please upload your screenshot in the screenshot channel.")

@bot.event
async def on_message(message):
    await bot.process_commands(message)
    if message.channel.id == SCREENSHOT_CHANNEL_ID and message.attachments:
        guild = bot.get_guild(GUILD_ID)
        role = guild.get_role(ROLE_ID)
        try:
            await message.author.add_roles(role)
            await message.channel.send(f"{message.author.mention} verified! Role added.")
        except:
            pass

bot.run(TOKEN)
